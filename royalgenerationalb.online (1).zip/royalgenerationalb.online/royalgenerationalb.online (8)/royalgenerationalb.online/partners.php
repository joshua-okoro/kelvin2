<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Best Forex Broker | Regulated Forex Trading, Indicies &amp; More | Royal Generational Bank </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="icon" href="assets/img/newfavicon.ico" type="image/x-icon" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,600,600i,700,700i|Satisfy|Comic+Neue:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>


<body style="background-color: whitesmoke">

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-flex align-items-center fixed-top topbar-transparent"  style="background-color: black">
    <div class="container text-right">
      <i class="icofont-phone"></i> +233206896912 +233591439840 
      <i class="icofont-clock-time icofont-rotate-180"></i> Mon-Sat: 11:00 AM - 23:00 PM
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center header-transparent" style="background-color: black">
    <div class="container d-flex align-items-center">

      <div class="logo mr-auto">
         <a href="index.php"><img src="assets/img/logo.jpeg" alt="" class="img-thumbnail" style="height:300px; width:150px"></a>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          
          <li><a href="index.php">HOME</a></li>
          <li><a href="trading.php">CAREER</a></li>
          <li><a href="aboutus.php">ABOUT US</a></li>
          <li><a href="platforms.php">PLATFORMS</a></li>
          <li><a href="client.php">CLIENTS</a></li>
          <li><a href="partners.php">PARTNERS</a></li>
          <li><a href="contact.php">CONTACT US</a></li>
          <li class="book-a-table text-center"><a href="register.php"  target="_blank">REGISTER ACCOUNT</a></li>
       
       
       <div id="google_translate_element"></div>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">
function googleTranslateElementInit() {
    
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
  
        $.getJSON("https://justmyip.org/api",function(result){
            console.log(result);
            country_code = result.geo.country_code.toLowerCase();
            new google.translate.TranslateElement({
                pageLanguage: country_code
            }, 'google_translate_element');

        });

}
</script>

       
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <br><br><br><br><br><br>
  <main id="main">
    <section>
      <div class="container-fluid">

        <div class="row">

          <div class="col-md-6 offset-md-3 d-flex justify-content-center">
            <div class="jumbotron" style="background-color: white">
              <h2 style="color: mediumblue">EARN MORE AS A Royal Generational Bank INTRODUCING BROKER</h2>
              <p style="font-size: 12px">
               The Vantage FX IB program is designed to offer individuals and corporate clients an opportunity to earn ongoing revenue from the trading activity of their clients.

<br><br>
Because we value the business that you bring, we reward IBs with some of the best rebates in the industry. Our IBs also tend to earn more than they would with other brokers by leveraging our strong brand reputation, award winning customer service, transparent IB reporting, as well as superior IB infrastructure.

<br><br>
Become a Vantage FX IB today and unlock access to higher rebates.


              </p>
            </div>
          </div>
        
        </div>

      </div>
    </section>


    <section>

      <div class="container-fluid">

        <div class="row">

          <div class="col-md-6 offset-md-3 d-flex justify-content-center">

            <div class="jumbotron" style="background-color: white">

              <div class="row">

                <div class="col-md-7">
                  <h2 style="color: mediumblue">The advantage of becoming an IB with Vantage FX</h2>
                    <p style="font-size: 12px">As a Vantage FX IB, on top of generous rebates and outstanding customer service, you’re gaining the support of a market leader by partnering with a leading recognised and trusted brand.<br><br>


                   We offer all our IBs complete transparency through our IB portal, where you receive total visibility of your accounts and customisable reporting, enabling you to keep track of rebates in real-time as well as the ability to view information about clients’ trading activity.<br><br>


                   Take advantage of our generous rebates and second-to-none service by becoming a Vantage FX IB.
                    </p>
                </div>

                <div class="col-md-5">
                  <img class="img-thumbnail img-responsive" src="assets/img/partnerone.jpg"/>
                </div>

              </div> <!-- row -->


            </div> <!-- jumbotron -->

          </div> <!-- col-md-6 -->
        
        </div> <!-- row -->

      </div> <!-- container fluid -->
    
    </section>




    <section>

      <div class="container-fluid">

        <div class="row">

          <div class="col-md-6 offset-md-3 d-flex justify-content-center">

            <div class="jumbotron" style="background-color: white">

              <div class="row">

                <div class="col-md-7">
                  <h2 style="color: mediumblue">We take care of your clients</h2>
                    <p style="font-size: 12px">When an IB refers a client to Vantage FX, we handle everything from opening their account to securing their funds, so you’re free to focus on more referrals and therefore more rebates.

<br><br>


                   Also, you can offer your clients the peace of mind in knowing that they’re trading with an award-winning, leading regulated broker. And, all client funds are held in segregated trust accounts so they can rest assured that they’re money is in safe hands.<br><br>


                   Offer your clients the opportunity to experience the Vantage FX difference by joining our IB program.
                    </p>
                </div>

                <div class="col-md-5">
                  <img class="img-thumbnail img-responsive" src="assets/img/partnertwo.jpg"/>
                </div>

              </div> <!-- row -->


            </div> <!-- jumbotron -->

          </div> <!-- col-md-6 -->
        
        </div> <!-- row -->

      </div> <!-- container fluid -->
    
    </section>

  </main>



  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <h3>ROYAL GENERATIONAL BANK </h3>
      <p><font color:"blue">Royal Generational Bank Ghana PLC and Royal Generational Bank PLC <br> are each authorised by the Prudential Regulation Authority and regulated<br> by the
Financial Conduct Authority and the Prudential Regulation Authority.<br>

Post Insurance Services Company Limited and Post Investment Solutions Limited are each <br>authorised and regulated by the
Financial Conduct Authority.</color></p>
      <div class="social-links">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>ROYAL GENERATIONAL BANK </span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/jquery-sticky/jquery.sticky.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>